package testB;
import static org.junit.Assert.*;
import org.junit.Test;


public class TestHashTable {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
