package phaseB;


public class Correlator {
	
	
    public static void main(String[] args) {
    	double variance = 0.0;  // TODO: Compute this variance
    	System.out.println(variance);  // IMPORTANT: Do not change printing format. Just print the double.
    }
}
